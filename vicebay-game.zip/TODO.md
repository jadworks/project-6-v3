# Vice Bay Nights delivery outcomes

- [ ] Build a playable English-language third-person open world with four distinct districts: beachfront/neon strip, downtown and bank, port and docks, and outskirts/wetlands; include roads, beaches, boardwalk, pier, bridges, warehouses, containers, cranes, ramps and safehouses. Provide clear minimap/world-map markers, interactive props and performance-conscious instancing/culling.
- [ ] Provide smooth on-foot movement, sprint, jump/vault, crouch, swimming and vehicle entry/exit, with hit and knockback reactions.
- [ ] Implement varied driveable vehicles with suspension, braking dive, acceleration squat, body roll, speed-sensitive steering, tire grip/handbrake drift, surface differences, collision damage, smoke, fire, dents and break-off effects.
- [ ] Add animated water, varied road/ground/building materials, lane details, windows, neon and vehicle/streetlight glows, as well as fog, shadows, weather and day/night transitions with controlled bloom.
- [ ] Add moving multi-lane traffic, pedestrian walking and fleeing, wildlife, and wanted escalation with police patrols, roadblocks, tactical response and helicopter pursuit. Connect combat effects, ammunition and visible impacts to actual gameplay.
- [ ] Add missions, races, stunts, deliveries/bounties, upgrades, safehouses, cinematics and persistent progress through real gameplay, with HUD, pause and map menus and procedural audio for vehicles, sirens, combat and radio.
- [x] Stabilize browser startup and add five visible stores that can be robbed with contextual interaction, cash rewards, heat escalation and local progress.
- [x] Slow police patrol and pursuit vehicles and retune their pursuit response.
- [x] Add a layered procedural gunshot and an original red/white/black/grey segmented wanted meter with clearer alert states.
- [x] Strengthen low-rise/high-rise building silhouettes while preserving instancing and distance culling.
- [x] Continue the realism pass with multi-road pedestrian/traffic coverage, grounded camera grading, speed-sensitive camera pullback, and heavier vehicle braking response.
- [ ] Configure the selected online leaderboard and Stripe integration. Do not invent prices or claim unverified checkout, server persistence or global leaderboard functionality.
- [ ] Offer an optional no-ads pass at €2.99 EUR per month as a recurring Stripe subscription, with clear recurring billing, cancellation and subscription status. Preserve offline play, attach purchases to a durable player identity, and disclose that the current game contains no ads for any player.
- [x] Validate a production build, live preview and meaningful gameplay transitions. Document any unavailable premium model generation or unimplemented approved scope accurately.

## Current implementation and remaining limits

The game remains a procedural, asset-free browser build. Five stores are represented by instanced buildings and sign textures, and robbery state is local to the current save/session. The new wanted display is an original segmented alert meter rather than a copied third-party game interface. Vehicles, people, environments, sound and animations remain procedural. High-quality generated 3D models and rigged animation are still deferred. Guest leaderboard scores remain browser-local and client-reported, and the Stripe sandbox remains unclaimed.
